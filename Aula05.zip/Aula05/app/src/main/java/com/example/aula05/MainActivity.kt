package com.example.aula05

import android.app.Activity
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.aula05.R.id.recycler_view
import com.example.aula05.model.Pessoa
import java.math.BigDecimal

class MainActivity: Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_constrait)

        // Mostra a variável nome, achando pelo id <de uma TextView>(R - recurso. tipo - ID. nomeID)
        /*val nome = findViewById<TextView>(R.id.nome_pessoa)
        nome.setText("Léscillei")

        val idade = findViewById<TextView>(R.id.idade_pessoa)
        idade.setText("23")

        val  profissao = findViewById<TextView>(R.id.profissao_pessoa)
        profissao.setText("Aluna") */


        val recyclerView = findViewById<RecyclerView>(recycler_view)
        recyclerView.adapter = ListarPessoaAdapter(pessoas = listOf(
            Pessoa(nome = "Léscillei", idade = 23, profissao = "Aluna" , altura = BigDecimal(1.63))
        ))

    }
}