package com.example.aula05.model

import java.math.BigDecimal

data class Pessoa (val nome : String, val idade : Int, val profissao : String, val altura : BigDecimal){
    /* data class Pessoa ou usar toString */
    /*override fun toString(): String {
        return "Nome: $nome, Idade : $idade, Profissao: $profissao, Altura: $altura"
    }*/
}